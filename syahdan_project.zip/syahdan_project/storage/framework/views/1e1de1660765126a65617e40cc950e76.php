<!-- resources/views/welcome.blade.php -->
<!DOCTYPE html>
   <html lang="en">
   <head>
       <meta charset="UTF-8">
       <meta name="viewport" content="width=device-width, initial-scale=1.0">
       <title>Selamat Datang di Laravel</title>
   </head>
   <body>
       <h1>Halo, Selamat Datang di Laravel!</h1>
       <p>Ini adalah halaman pertama yang menggunakan Blade Template.</p>
   </body>
   </html>
<?php /**PATH C:\xampp\htdocs\sadan_project\resources\views/welcome.blade.php ENDPATH**/ ?>